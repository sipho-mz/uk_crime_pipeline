UK Crime data pipeline
